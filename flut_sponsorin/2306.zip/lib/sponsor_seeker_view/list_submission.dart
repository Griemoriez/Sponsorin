import 'package:flutter/material.dart';

class list_submission extends StatelessWidget {
  const list_submission({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
            child: Text(
              'List Submission TEST',
              style: TextStyle(fontSize: 24, color: Colors.red),
            ),
          ),
    );
  }
}
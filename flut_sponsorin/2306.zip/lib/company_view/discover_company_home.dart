import 'package:flutter/material.dart';

class discover_company_home extends StatelessWidget {
  const discover_company_home({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
            child: Text(
              'Discovery Home',
              style: TextStyle(fontSize: 24, color: Colors.black),
            ),
          ),
    );
  }
}
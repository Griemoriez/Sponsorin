import 'package:flutter/material.dart';

class profile_company extends StatelessWidget {
  const profile_company({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
            child: Text(
              'profile',
              style: TextStyle(fontSize: 24, color: Colors.black),
            ),
          ),
    );
  }
}